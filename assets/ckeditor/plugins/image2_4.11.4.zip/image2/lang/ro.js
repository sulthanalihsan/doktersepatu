/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'ro', {
	alt: 'Text alternativ',
	btnUpload: 'Încarcă pe server',
	captioned: 'Descris',
	captionPlaceholder: 'Descriere implicită',
	infoTab: 'Informaţii despre imagine',
	lockRatio: 'Păstrează proporţiile',
	menu: 'Proprietăţile imaginii',
	pathName: 'Adresa căii',
	pathNameCaption: 'Descrierea numelui căii',
	resetSize: 'Resetează mărimea',
	resizer: 'Redimensionare dinamică',
	title: 'Proprietăţile imaginii',
	uploadTab: 'Încarcă',
	urlMissing: 'Sursa URL a imaginii lipsește.',
	altMissing: 'Textul alternativ descriptive lipsește!'
} );
